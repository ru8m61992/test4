$(document).ready(function(){

  

  $(".member-menu").on('click',function(){
    reset();
    init();

    if(!$(this).hasClass('member-menu-float-show')) {
      $(this).addClass('member-menu-float-show')
      $(".member-menu-float").show();
      $(".block").show();
  
      $(".member-menu").css("z-index",2000);
      $(".member-menu").css('background-color','#0169b8');

      $(".member-menu .mobile-login-float-item-arrow").css("transform","rotate(-180deg)")
    }else{
      $(this).removeClass('member-menu-float-show')
      init();
      $(".member-menu .mobile-login-float-item-arrow").css("transform","")
    }
  })

  

  $(".alert-close-btn").on('click',function(){
    $(".width-alert").slideUp();
  })

    
  $(".news_list-block-body-single tr").click(function(){
    var self = $(this).find(".news_list-block-body-single-click");
		var title = $(this).find("td:nth-child(3)");
    var content = self.parent().next().find(".news_list-block-body-single-content");
    var img = self.find('img');
    if(content.is(":visible") == true){
      content.slideUp();
      img.css("transform","")
			title.css("font-weight","500");
    } else {
      content.slideDown();
      img.css("transform","rotate(90deg)")
			title.css("font-weight","900");
		
    }
  })
  

  $(".width-alert-cross").click(function(){
    $(".width-alert").slideUp();
  })

  $(".lastest-single-event-button").on('click',function(){
    
    if($(".lastest-single-event-last").is(":visible") == true){
      $(".lastest-single-event-last").hide();
      $(".lastest-single-event-button-text").text("展開");
      $(".lastest-single-event-button img").css("transform","rotate(0deg)");
      $(".lastest-event-wrapper").removeClass('lastest-event-wrapper-remove-after');
    }else{
      $(".lastest-single-event-last").show();
      $(".lastest-single-event-button-text").text("收合");
      $(".lastest-single-event-button img").css("transform","rotate(-180deg)");
      $(".lastest-event-wrapper").addClass('lastest-event-wrapper-remove-after');
    }
  })

  $(".advantage-btn").on('click',function() {
    var top = $(".advantage-big-title").offset().top - 136
    $('html,body').animate({ scrollTop: top }, 'slow'); 
    return false;
  })

  $(".shelf-btn").on('click',function() {
    var top = $(".feature-big-title").offset().top - 136
    $('html,body').animate({ scrollTop: top }, 'slow'); 
    return false;
  })

  $(".understand-btn,.pinkwhite-btn").on('click',function() {
    var top = $(".ready-big-title").offset().top - 136
    $('html,body').animate({ scrollTop: top }, 'slow'); 
    return false;
  })

  $(".lastest-left-info-single").on('click',function(){
    var index = $(this).index();
    window.open("./news_list.html#list_"+parseInt(parseInt(index)))
  })
	var $window = $(window);
	var windowsize = $window.width();

	if( windowsize <= 768 ) {
  $(".sell-product").on('click',function(){
    reset();

    if(!$(this).hasClass('sell-product-float-show')) {
      $(this).addClass('sell-product-float-show')
      $(".sell-product-float").show();
      $(".block").show();

      $(this).css("z-index",2000);
      $(this).css('background-color','#0169b8');

      $(".sell-product .mobile-login-float-item-arrow").css("transform","rotate(-180deg)")
    }else{
      $(this).removeClass('sell-product-float-show')
      init();

      $(".sell-product .mobile-login-float-item-arrow").css("transform","")
    }
  })
  

  $(".order-query").on('click',function(){
    reset();

    if(!$(this).hasClass('order-product-float-show')) {
      $(this).addClass('order-product-float-show')
      $(".order-query-float").show();
      $(".block").show();
      $(".order-query").css("z-index",2000);
      $(".order-query").css('background-color','#0169b8');

      $(".order-query .mobile-login-float-item-arrow").css("transform","rotate(-180deg)")
    }else{
      $(this).removeClass('order-product-float-show')
      init();
      $(".order-query .mobile-login-float-item-arrow").css("transform","")
    }
    
  })
  
  

  $(".accounting-query").on('click',function(){
    reset();

    if(!$(this).hasClass('accounting-query-float-show')) {
      $(this).addClass('accounting-query-float-show')
      $(".accounting-query-float").show();
      $(".block").show();
  
      $(".accounting-query").css("z-index",2000);
      $(".accounting-query").css('background-color','#0169b8');

      $(".accounting-query .mobile-login-float-item-arrow").css("transform","rotate(-180deg)")
    }else{
      $(this).removeClass('accounting-query-float-show')
      init();

      $(".accounting-query .mobile-login-float-item-arrow").css("transform","")
    }
  })
  

  $(".give-product").on('click',function(){
    reset();

    if(!$(this).hasClass('give-product-float-show')) {
      $(this).addClass('give-product-float-show')
      $(".give-product-float").show();
      $(".block").show();

      $(".give-product").css("z-index",2000);
      $(".give-product").css('background-color','#0169b8');

      $(".give-product .mobile-login-float-item-arrow").css("transform","rotate(-180deg)")
    }else{
      $(this).removeClass('give-product-float-show')
      init();
      $(".give-product .mobile-login-float-item-arrow").css("transform","")
    }
   
  })
 

  $(".app-download").on('click',function(){
    reset();

    if(!$(this).hasClass('app-download-float-show')) {
      $(this).addClass('app-download-float-show')
      $(".app-download-float").show();
      $(".block").show();
  
      $(".app-download").css("z-index",2000);
      $(".app-download").css('background-color','#0169b8');

      $(".app-download .mobile-login-float-item-arrow").css("transform","rotate(-180deg)")
    }else{
      $(this).removeClass('app-download-float-show')
      init();
      $(".app-download .mobile-login-float-item-arrow").css("transform","")
    }
   
  })
    
    
		resetMobileImage();
    
    $(".pinkwhite-btn").on('click',function() {
			var top = $(".ready-big-title").offset().top - 20
			$('html,body').animate({ scrollTop: top }, 'slow'); 
      init();
      $(".block2").hide();
			return false;
		})
    
    $(".lastest-single-event-content").text(function(index,text){
      if(text.length > 36 ){
        $(this).text(text.substring(0,36)+"...");
      }
      
    })
	} else {
    
    $(".sell-product").mouseenter(function(event){
      init();
      if(!$(this).hasClass('sell-product-float-show')) {
        $(this).addClass('sell-product-float-show')
        $(".sell-product-float").show();
        $(".block").show();

        $(this).css("z-index",2000);
        $(this).css('background-color','#0169b8');

        $(".sell-product .mobile-login-float-item-arrow").css("transform","rotate(-180deg)")
      }else{
        $(this).removeClass('sell-product-float-show')
        init();

        $(".sell-product .mobile-login-float-item-arrow").css("transform","")
      }
    })
    
    $(".order-query").mouseenter(function(event){
      init();

      if(!$(this).hasClass('order-product-float-show')) {
        $(this).addClass('order-product-float-show')
        $(".order-query-float").show();
        $(".block").show();
        $(".order-query").css("z-index",2000);
        $(".order-query").css('background-color','#0169b8');

        $(".order-query .mobile-login-float-item-arrow").css("transform","rotate(-180deg)")
      }else{
        $(this).removeClass('order-product-float-show')
        init();
        $(".order-query .mobile-login-float-item-arrow").css("transform","")
      }
      
    })
  
    $(".accounting-query").mouseenter(function(event){
      init();

      if(!$(this).hasClass('accounting-query-float-show')) {
        $(this).addClass('accounting-query-float-show')
        $(".accounting-query-float").show();
        $(".block").show();
    
        $(".accounting-query").css("z-index",2000);
        $(".accounting-query").css('background-color','#0169b8');

        $(".accounting-query .mobile-login-float-item-arrow").css("transform","rotate(-180deg)")
      }else{
        $(this).removeClass('accounting-query-float-show')
        init();

        $(".accounting-query .mobile-login-float-item-arrow").css("transform","")
      }
    })

    $(".give-product").mouseenter(function(event){
      init();

      if(!$(this).hasClass('give-product-float-show')) {
        $(this).addClass('give-product-float-show')
        $(".give-product-float").show();
        $(".block").show();

        $(".give-product").css("z-index",2000);
        $(".give-product").css('background-color','#0169b8');

        $(".give-product .mobile-login-float-item-arrow").css("transform","rotate(-180deg)")
      }else{
        $(this).removeClass('give-product-float-show')
        init();
        $(".give-product .mobile-login-float-item-arrow").css("transform","")
      }
     
    })
  
    $(".app-download").mouseenter(function(event){
      init();

      if(!$(this).hasClass('app-download-float-show')) {
        $(this).addClass('app-download-float-show')
        $(".app-download-float").show();
        $(".block").show();
    
        $(".app-download").css("z-index",2000);
        $(".app-download").css('background-color','#0169b8');

        $(".app-download .mobile-login-float-item-arrow").css("transform","rotate(-180deg)")
      }else{
        $(this).removeClass('app-download-float-show')
        init();
        $(".app-download .mobile-login-float-item-arrow").css("transform","")
      }
     
    })

  }
  
  
	$(".block").mouseover(function(){
    console.log("aa")
		init()
	})
	
	
  
});

function init() {
  $(".give-product").css('background-color','transparent');
  $(".sell-product").css('background-color','transparent');
  $(".order-query").css('background-color','transparent');
  $(".accounting-query").css('background-color','transparent');
  $(".app-download").css('background-color','transparent');
  $(".member-menu").css('background-color','transparent');
  
  $(".sell-product").removeClass('sell-product-float-show');
  $(".order-query").removeClass('order-product-float-show');
  $(".give-product").removeClass('give-product-float-show');
  $(".accounting-query").removeClass('accounting-query-float-show');
  $(".app-download").removeClass('app-download-float-show');
  
  $(".block").hide();
  
  $(".give-product").css("z-index",1);
  $(".sell-product").css("z-index",1);
  $(".order-query").css("z-index",1);
  $(".accounting-query").css("z-index",1);
  $(".app-download").css("z-index",1);
  $(".member-menu").css("z-index",1);

  $(".give-product-float").hide();
  $(".sell-product-float").hide();
  $(".order-query-float").hide();
  $(".accounting-query-float").hide();
  $(".app-download-float").hide();
  $(".member-menu-float").hide();
  
  $(".mobile-login-float-item-arrow").css("transform","rotate(0deg)")
}

//reset
function reset(){
  $(".sell-product-background-text,.block,.order-query-background-text,.accounting-query-background-text,.member_menu").off('click');
  $(".sell-product-background-text,.block,.order-query-background-text,.accounting-query-background-text,.member_menu").on('click',function(event){
    event.stopPropagation();
    init();
  })
}

function resetMenuToggle(){
  $(".toggle_login_menu").on('click',function(){
    if($(".login_float").is(":visible") == true) {
      $(".login_header_img").css("transform","rotateZ(-180deg)");
      $(".login_float").slideUp();
    } else{
      $(".login_header_img").css("transform","rotateZ(0deg)");
      $(".login_float").slideDown();
    }
  })
}

function resetMobileMenuToggle(){
  $(".header-nav-button").off('click');
  $(".header-nav-button").on('click',function(){
    
    if($(".mobile-login-float").is(":visible") == true) {
      $(".mobile-login-float").slideUp();
      init();
      $(".block2").hide();
      $(".block").hide();
    } else{
      $(".mobile-login-float").slideDown();
      reset();
      $(".block2").show();
      
    }
  })
  $(".block2").off('click');
  $(".block2").on('click',function(){
    init();
    $(".mobile-login-float").slideUp();
    $(".block2").hide();
    $(".block").hide();
  })
}

function resetMobileImage() {
  $(".mobile-slider-item-advantage").off('click');
  $(".mobile-slider-item-advantage").on('click',function() {
    var top = $(".advantage-big-title").offset().top - 20
    $('html,body').animate({ scrollTop: top }, 'slow'); 
    init();
    $(".block").hide();
    return false;
  })
  $(".mobile-slider-item-shelf").off('click');
  $(".mobile-slider-item-shelf").on('click',function() {
    var top = $(".feature-big-title").offset().top - 20
    $('html,body').animate({ scrollTop: top }, 'slow'); 
    init();
    $(".block").hide();
    return false;
  })
  $(".mobile-slider-item-understand").off('click');
  $(".mobile-slider-item-understand").on('click',function() {
    var top = $(".ready-big-title").offset().top - 20
    $('html,body').animate({ scrollTop: top }, 'slow'); 
    init();
    $(".block2").hide();
    return false;
  })
}